# Historique des commandes — Docker Network Toolkit

> Source : sortie `history 1` fournie par l’utilisateur. Relevé chronologique de **147 entrées d’historique Zsh**. Une entrée peut contenir plusieurs commandes collées.

> **Attention : ce document est un historique, pas un script à exécuter.** Certaines commandes sont erronées, modifient le système ou ont été retapées plusieurs fois. Les explications précisent les cas identifiés. Les résultats d’exécution ne sont pas déductibles du seul historique.

> Confidentialité : l’adresse e-mail figurant dans une commande Git a été masquée. Vérifier les informations locales (IP, chemins, noms de compte) avant publication sur un dépôt public.

## Vue d’ensemble

| Étape | Entrées | Objet |
|---|---:|---|
| Installation et préparation Ubuntu, Zsh et Docker | 1–13 | 13 entrées |
| Création de la stack Docker et documentation réseau | 14–33 | 20 entrées |
| Premiers essais Dockerfile, fichiers et dépannage | 34–45 | 12 entrées |
| Images Docker, conteneurs, diagnostics et erreurs de syntaxe | 46–94 | 49 entrées |
| Tags, copie du projet, Git et signature SSH | 95–121 | 27 entrées |
| Correction et reconstruction de la Toolbox | 122–135 | 14 entrées |
| Commits, authentification SSH, push et vérifications finales | 136–147 | 12 entrées |

## Commandes dans l’ordre de saisie

### Installation et préparation Ubuntu, Zsh et Docker — entrées 1 à 13

**Entrée 001**

`````bash
exit
`````

**Entrée 002**

`````bash
sudo apt update && sudo apt install -y zsh git curl fzf
sh -c "$(curl -fsSL https://raw.githubusercontent.com/ohmyzsh/ohmyzsh/master/tools/install.sh)" "" --unattended
ZC=${ZSH_CUSTOM:-$HOME/.oh-my-zsh/custom}
for p in zsh-users/zsh-autosuggestions zsh-users/zsh-syntax-highlighting zsh-users/zsh-completions Aloxaf/fzf-tab; do
  [ -d "$ZC/plugins/${p#*/}" ] || git clone https://github.com/$p "$ZC/plugins/${p#*/}"
done
sed -i 's/^plugins=(.*)/plugins=(git command-not-found fzf fzf-tab zsh-completions zsh-autosuggestions zsh-syntax-highlighting)/' ~/.zshrc
grep -q ZSH_AUTOSUGGEST_STRATEGY ~/.zshrc || sed -i '1i ZSH_AUTOSUGGEST_STRATEGY=(history completion)' ~/.zshrc
grep -q "use-cache off" ~/.zshrc || echo "zstyle ':completion:*' use-cache off" >> ~/.zshrc
chsh -s "$(which zsh)"
rm -f ~/.zcompdump* ~/.oh-my-zsh/cache/DEBS_* 2>/dev/null
exec zsh
`````

*Note : Installation/configuration du shell Zsh et de ses plugins. Inclut des changements sur ~/.zshrc, chsh et la suppression d’anciens caches.*

**Entrée 003**

`````bash
sudo apt install open-vm-tools open-vm-tools-desktop -y
`````

**Entrée 004**

`````bash
set -e

. /etc/os-release

case "$ID" in
  debian)
    DOCKER_OS="debian"
    DOCKER_CODENAME="$VERSION_CODENAME"
    ;;
  ubuntu)
    DOCKER_OS="ubuntu"
    DOCKER_CODENAME="${UBUNTU_CODENAME:-$VERSION_CODENAME}"
    ;;
  *)
    echo "Distribution non prise en charge : $ID"
    return 1 2>/dev/null || exit 1
    ;;
esac

sudo apt update
sudo apt install -y ca-certificates curl

sudo install -m 0755 -d /etc/apt/keyrings

sudo curl -fsSL "https://download.docker.com/linux/$DOCKER_OS/gpg" \
  -o /etc/apt/keyrings/docker.asc

sudo chmod a+r /etc/apt/keyrings/docker.asc

sudo tee /etc/apt/sources.list.d/docker.sources > /dev/null <<EOF
Types: deb
URIs: https://download.docker.com/linux/$DOCKER_OS
Suites: $DOCKER_CODENAME
Components: stable
Architectures: $(dpkg --print-architecture)
Signed-By: /etc/apt/keyrings/docker.asc
EOF

sudo apt update

sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

sudo systemctl enable --now docker

sudo docker run hello-world

docker compose version
`````

*Note : Script de configuration du dépôt officiel Docker et installation du moteur, des plugins Buildx/Compose et du service.*

**Entrée 005**

`````bash
sudo usermod -aG docker "$USER"
newgrp docker
`````

*Note : Ajout de l’utilisateur au groupe docker : équivaut à un accès privilégié au démon Docker.*

**Entrée 006**

`````bash
docker run hello-world
docker compose version
`````

**Entrée 007**

`````bash
docker version
docker compose version
docker run hello-world
`````

**Entrée 008**

`````bash
sudo docker run hello-world
`````

**Entrée 009**

`````bash
sudo usermod -aG docker "$USER"
`````

**Entrée 010**

`````bash
newgrp docker
`````

**Entrée 011**

`````bash
sudo apt install util-linux-extra
`````

**Entrée 012**

`````bash
newgrp docker
`````

**Entrée 013**

`````bash
id -nG
docker version
docker run hello-world
docker compose version
`````

### Création de la stack Docker et documentation réseau — entrées 14 à 33

**Entrée 014**

`````bash
mkdir -p ~/Docker-Network-Toolkit/{containers/toolbox,containers/iperf3,web,scripts,docs/architecture,docs/tests,.github/workflows}

cd ~/Docker-Network-Toolkit

pwd
`````

*Note : Création de l’arborescence initiale du laboratoire.*

**Entrée 015**

`````bash
cat > containers/toolbox/Dockerfile <<'EOF'
FROM debian:trixie-slim

ENV DEBIAN_FRONTEND=noninteractive

RUN apt-get update \
    && apt-get install -y --no-install-recommends \
        bash \
        ca-certificates \
        curl \
        dnsutils \
        fzf \
        iperf3 \
        iproute2 \
        iputils-ping \
        mtr-tiny \
        netcat-openbsd \
        nmap \
        procps \
        tcpdump \
        traceroute \
        wget \
        less \
        vim-tiny \
    && rm -rf /var/lib/apt/lists/*

WORKDIR /workspace

CMD ["sleep", "infinity"]
EOF
`````

*Note : Version initiale du Dockerfile toolbox basée sur Debian.*

**Entrée 016**

`````bash
cat > containers/iperf3/Dockerfile <<'EOF'
FROM debian:trixie-slim

ENV DEBIAN_FRONTEND=noninteractive

RUN apt-get update \
    && apt-get install -y --no-install-recommends iperf3 passwd \
    && rm -rf /var/lib/apt/lists/* \
    && useradd --system --uid 10001 --no-create-home iperf

USER 10001:10001

EXPOSE 5201

CMD ["iperf3", "--server"]
EOF
`````

*Note : Dockerfile iperf3 avec utilisateur non privilégié 10001.*

**Entrée 017**

`````bash
cat > web/index.html <<'EOF'
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Docker Network Toolkit</title>
</head>
<body>
    <h1>Docker Network Toolkit</h1>
    <p>Le serveur web fonctionne correctement.</p>
    <p>Service : web</p>
    <p>Infrastructure : Docker Compose</p>
</body>
</html>
EOF
`````

**Entrée 018**

`````bash
cat > compose.yaml <<'EOF'
name: docker-network-toolkit

services:
  toolbox:
    build:
      context: ./containers/toolbox
    image: docker-network-toolkit/toolbox:1.0
    container_name: dnt-toolbox
    command: ["sleep", "infinity"]
    working_dir: /workspace
    cap_add:
      - NET_RAW
    networks:
      - toolkit

  web:
    image: nginx:stable-alpine
    container_name: dnt-web
    ports:
      - "8080:80"
    volumes:
      - ./web:/usr/share/nginx/html:ro
    restart: unless-stopped
    networks:
      - toolkit

  iperf3-server:
    build:
      context: ./containers/iperf3
    image: docker-network-toolkit/iperf3-server:1.0
    container_name: dnt-iperf3
    expose:
      - "5201"
    restart: unless-stopped
    networks:
      - toolkit

networks:
  toolkit:
    name: dnt-network
    driver: bridge
EOF
`````

*Note : Configuration initiale des trois services Compose et du réseau dnt-network.*

**Entrée 019**

`````bash
cat > scripts/test-stack.sh <<'EOF'
#!/usr/bin/env bash

set -euo pipefail

docker compose exec -T toolbox bash -lc '
set -euo pipefail

echo "===== DNS ====="
getent hosts web
getent hosts iperf3-server

echo
echo "===== PING ====="
ping -c 3 web

echo
echo "===== HTTP ====="
curl -fsS http://web/

echo
echo "===== NMAP ====="
nmap -sT -p 80 web

echo
echo "===== IPERF3 ====="
iperf3 -c iperf3-server -t 5

echo
echo "Tous les tests ont réussi."
'
EOF

chmod +x scripts/test-stack.sh
`````

*Note : Création du script de test automatique du réseau.*

**Entrée 020**

`````bash
cat > .gitignore <<'EOF'
.env
.env.*
!.env.example

*.log
*.pcap
*.pcapng

backup/
backups/
tmp/

.DS_Store
EOF
`````

**Entrée 021**

`````bash
docker compose config -q
`````

*Note : Validation de syntaxe de Compose.*

**Entrée 022**

`````bash
docker compose up -d --build
`````

*Note : Construction et démarrage de la stack.*

**Entrée 023**

`````bash
docker compose ps
`````

**Entrée 024**

`````bash
curl http://localhost:8080
`````

**Entrée 025**

`````bash
./scripts/test-stack.sh
`````

**Entrée 026**

`````bash
echo "========== MACHINE VIRTUELLE =========="
hostname
ip -br addr
ip route

echo
echo "========== RESEAU DOCKER =========="
docker network inspect dnt-network

echo
echo "========== ADRESSES DES CONTENEURS =========="
for container in dnt-toolbox dnt-web dnt-iperf3; do
    echo "===== $container ====="
    docker inspect -f '{{range .NetworkSettings.Networks}}{{.IPAddress}}/{{.IPPrefixLen}} | Gateway: {{.Gateway}}{{end}}' "$container"
done

echo
echo "========== PORTS EXPOSES =========="
docker compose port web 80
`````

*Note : Relevé de la VM, du réseau Docker et des adresses des conteneurs.*

**Entrée 027**

`````bash
cat > docs/architecture/network.md <<'EOF'
# Architecture réseau

## 1. Présentation

L'infrastructure repose sur une machine virtuelle Linux hébergée avec VMware.
Docker Engine y exécute trois conteneurs reliés par un réseau bridge personnalisé.

## 2. Machine virtuelle

| Élément | Configuration |
|---|---|
| Plateforme | VMware |
| Interface réseau | ens33 |
| Adresse IP | 192.168.196.131 |
| Masque | 255.255.255.0 (/24) |
| Réseau | 192.168.196.0/24 |
| Passerelle | 192.168.196.2 |

## 3. Réseau Docker

| Élément | Configuration |
|---|---|
| Nom | dnt-network |
| Driver | bridge |
| Interface Linux | br-b75d7f8a1831 |
| Sous-réseau | 172.18.0.0/16 |
| Passerelle | 172.18.0.1 |
| IPv6 | Désactivé |

## 4. Adressage des conteneurs

| Conteneur | Adresse IP | Fonction |
|---|---|---|
| dnt-web | 172.18.0.2 | Serveur web Nginx |
| dnt-toolbox | 172.18.0.3 | Outils de diagnostic |
| dnt-iperf3 | 172.18.0.4 | Serveur iperf3 |

Les adresses correspondent à l'état observé lors du relevé.
Elles peuvent changer après la recréation des conteneurs.

## 5. Publication des ports

| Service | Port conteneur | Port VM | Accès |
|---|---:|---:|---|
| Nginx | 80 | 8080 | Publié sur les interfaces IPv4 |
| iperf3 | 5201 | Non publié | Réseau Docker uniquement |

URL du serveur web :

http://192.168.196.131:8080

Le port 5201 d'iperf3 est exposé au réseau Docker, mais n'est pas publié sur la machine virtuelle.

## 6. Schéma réseau

```mermaid
flowchart TB
    CLIENT["Poste hôte / Client"]
    VM["Machine virtuelle Linux<br/>192.168.196.131/24"]
    NIC["Interface ens33"]
    DOCKER["Docker Engine"]
    BRIDGE["Bridge dnt-network<br/>172.18.0.1/16"]

    subgraph SERVICES["Conteneurs Docker"]
        WEB["dnt-web<br/>172.18.0.2<br/>TCP 80"]
        TOOLBOX["dnt-toolbox<br/>172.18.0.3"]
        IPERF["dnt-iperf3<br/>172.18.0.4<br/>TCP 5201"]
    end

    CLIENT --> VM
    VM --> NIC
    NIC --> DOCKER
    DOCKER --> BRIDGE
    BRIDGE --- WEB
    BRIDGE --- TOOLBOX
    BRIDGE --- IPERF

## 3. Vérifier la connectivité depuis l'interface VMware

Maintenant, exécute :

```bash
echo "===== VIRTUALISATION ====="
systemd-detect-virt

echo
echo "===== TEST HTTP VIA IP DE LA VM ====="
curl -I http://192.168.196.131:8080

echo
echo "===== PORTS EN ECOUTE ====="
sudo ss -lntp | grep -E ':8080|:5201'
`````

*Note : Tentative d’écriture de la documentation réseau : contenu Markdown partiellement incorrect/incomplet.*

*Attention : la commande contient un here-document incomplet dans l’historique ; ne pas la recopier telle quelle.*

**Entrée 028**

`````bash
systemd-detect-virt
`````

**Entrée 029**

`````bash
curl -I http://192.168.196.131:8080
`````

**Entrée 030**

`````bash
sudo ss -lntp | grep -E ':8080|:5201'
`````

**Entrée 031**

`````bash
cat > docs/architecture/network.md <<'EOF'
# Architecture réseau

## 1. Présentation

L'infrastructure repose sur une machine virtuelle Linux hébergée avec VMware.
Docker Engine y exécute trois conteneurs connectés à un réseau bridge personnalisé.

## 2. Machine virtuelle

| Élément | Configuration |
|---|---|
| Hyperviseur | VMware |
| Interface réseau | ens33 |
| Adresse IPv4 | 192.168.196.131 |
| Masque | 255.255.255.0 |
| Réseau | 192.168.196.0/24 |
| Passerelle | 192.168.196.2 |

## 3. Réseau Docker

| Élément | Configuration |
|---|---|
| Nom | dnt-network |
| Driver | bridge |
| Interface Linux | br-b75d7f8a1831 |
| Sous-réseau | 172.18.0.0/16 |
| Passerelle | 172.18.0.1 |
| IPv6 | Désactivé |

## 4. Adressage des conteneurs

| Conteneur | Adresse IP | Fonction |
|---|---|---|
| dnt-web | 172.18.0.2 | Serveur Nginx |
| dnt-toolbox | 172.18.0.3 | Outils de diagnostic |
| dnt-iperf3 | 172.18.0.4 | Serveur iperf3 |

Les adresses correspondent au relevé du 4 novembre 2026.
Elles peuvent changer après la recréation des conteneurs.

## 5. Publication des ports

| Service | Port conteneur | Port VM | Accès |
|---|---:|---:|---|
| Nginx | 80 | 8080 | Publié sur les interfaces IPv4 et IPv6 |
| iperf3 | 5201 | Non publié | Réseau Docker uniquement |

URL du serveur web :

http://192.168.196.131:8080

Le port 8080 de la VM est redirigé vers le port 80 du conteneur Nginx.

Le port 5201 est accessible entre les conteneurs, mais n'est pas publié sur la VM.

## 6. Schéma réseau

```mermaid
flowchart TB
    HOST["Poste hôte"]
    VM["VM Linux sous VMware<br/>192.168.196.131/24<br/>Interface ens33"]

    subgraph DOCKER["Docker Engine"]
        BRIDGE["Réseau bridge dnt-network<br/>172.18.0.0/16<br/>Passerelle 172.18.0.1"]

        subgraph SERVICES["Conteneurs"]
            WEB["dnt-web<br/>172.18.0.2<br/>Nginx : TCP 80"]
            TOOLBOX["dnt-toolbox<br/>172.18.0.3"]
            IPERF["dnt-iperf3<br/>172.18.0.4<br/>iperf3 : TCP 5201"]
        end

        BRIDGE --- WEB
        BRIDGE --- TOOLBOX
        BRIDGE --- IPERF
    end

    HOST --> VM
    VM -->|"Port 8080 vers TCP 80"| WEB

Vérifie que le fichier existe :

```bash
ls -l docs/architecture/network.md
`````

*Note : Nouvelle tentative d’écriture de la documentation réseau, également incomplète dans l’historique.*

*Attention : la commande contient un here-document incomplet dans l’historique ; ne pas la recopier telle quelle.*

**Entrée 032**

`````bash
cat >> docs/architecture/network.md <<'EOF'

## 11. Accès depuis le poste hôte

Un test de connectivité a été effectué depuis Windows PowerShell.

| Élément | Valeur |
|---|---|
| Interface Windows | VMware Network Adapter VMnet8 |
| Adresse source | 192.168.196.1 |
| Adresse destination | 192.168.196.131 |
| Port distant | TCP 8080 |
| Résultat | TcpTestSucceeded: True |

Le serveur Nginx est donc accessible depuis le poste hôte à l'adresse :

http://192.168.196.131:8080

Le test confirme la communication entre le poste Windows et le serveur web
hébergé dans un conteneur Docker sur la machine virtuelle.
EOF
`````

**Entrée 033**

`````bash
find . -maxdepth 3 -type f | sort
`````

*Note : Ajout de la section test d’accès HTTP depuis Windows.*

### Premiers essais Dockerfile, fichiers et dépannage — entrées 34 à 45

**Entrée 034**

`````bash
git status --short
`````

**Entrée 035**

`````bash
git init -b main
git status --short
`````

*Note : Initialisation Git dans l’ancien dossier local, distinct du clone GitHub effectué plus tard.*

**Entrée 036** — **erreur relevée**

`````bash
FROM ubuntu:latest
RUN apt-get update && apt-get install -y nmap iproute2 iputils-ping
CMD ["bash"]
`````

*Note : ERREUR : instructions Dockerfile saisies comme commandes du terminal.*

**Entrée 037**

`````bash
ls
`````

**Entrée 038**

`````bash
cd Bureau
`````

**Entrée 039**

`````bash
cd ..
`````

**Entrée 040**

`````bash
mkdir Dockerfile
`````

**Entrée 041**

`````bash
cd Dockerfile
`````

**Entrée 042** — **erreur relevée**

`````bash
FROM ubuntu:latest
RUN apt-get update && apt-get install -y nmap iproute2 iputils-ping
CMD ["bash"]
`````

*Note : ERREUR : instructions Dockerfile saisies dans le terminal après création d’un dossier nommé Dockerfile.*

**Entrée 043**

`````bash
curl -I http://192.168.196.131:8080
`````

**Entrée 044**

`````bash
sudo ss -lntp | grep -E ':8080|:5201'
`````

**Entrée 045**

`````bash
systemd-detect-virt
`````

### Images Docker, conteneurs, diagnostics et erreurs de syntaxe — entrées 46 à 94

**Entrée 046**

`````bash
docker --version
`````

**Entrée 047**

`````bash
docker ps
`````

**Entrée 048**

`````bash
cd ..
`````

**Entrée 049**

`````bash
mkdir network-utils
`````

*Note : Création du dossier pour les premiers essais d’image réseau.*

**Entrée 050**

`````bash
cd network-utils
`````

**Entrée 051**

`````bash
nano Dockerfile
`````

**Entrée 052**

`````bash
ls
`````

**Entrée 053**

`````bash
docker build -t network-utils:latest .
`````

*Note : Construction de l’image network-utils.*

**Entrée 054**

`````bash
docker images
`````

**Entrée 055**

`````bash
docker run -dit --name network-utils network-utils:latest
`````

*Note : Démarrage d’un conteneur de diagnostic.*

**Entrée 056**

`````bash
docker ps
`````

**Entrée 057**

`````bash
docker exec network-utils nmap -h
`````

**Entrée 058**

`````bash
docker exec network-utils ip a
`````

**Entrée 059**

`````bash
docker exec network-utils ping -c 1 8.8.8.8
`````

**Entrée 060**

`````bash
docker ps
`````

**Entrée 061**

`````bash
docker images
`````

**Entrée 062**

`````bash
docker container ls
`````

**Entrée 063**

`````bash
docker ps
`````

**Entrée 064**

`````bash
docker images
`````

**Entrée 065** — **erreur relevée**

`````bash
docker inspect netwok-utils:latest
`````

*Note : ERREUR : nom de l’image mal orthographié et usage de inspect à confirmer.*

**Entrée 066** — **erreur relevée**

`````bash
docker inspect
`````

*Note : ERREUR : docker inspect sans cible.*

**Entrée 067** — **erreur relevée**

`````bash
docker inspect netwok-utils|34389039f504
`````

*Note : ERREUR : caractère | interprété par le shell comme un pipe ; nom de cible incorrect.*

**Entrée 068** — **erreur relevée**

`````bash
docker inspect network-utils|34389039f504
`````

*Note : ERREUR : caractère | interprété comme un pipe ; syntaxe incorrecte.*

**Entrée 069** — **erreur relevée**

`````bash
docker inspect network-utils:latest
`````

*Note : ERREUR : docker inspect avec une référence d’image non valide ou absente.*

**Entrée 070**

`````bash
docker images
`````

**Entrée 071**

`````bash
ls
`````

**Entrée 072**

`````bash
nano Dockerfile-sans-tag
`````

**Entrée 073**

`````bash
ls
`````

**Entrée 074**

`````bash
docker image ls
`````

**Entrée 075**

`````bash
ls
`````

**Entrée 076** — **erreur relevée**

`````bash
docker image tag network-utils/Dockerfile-sans-tag:toolbox:1.0
`````

*Note : ERREUR : syntaxe de docker image tag incorrecte.*

**Entrée 077** — **erreur relevée**

`````bash
docker image tag Dockerfile-sans-tag:latest network-utils/Dockerfile-sans-tag:toolbox:1.0
`````

*Note : ERREUR : référence cible avec trop de séparateurs « : ».*

**Entrée 078** — **erreur relevée**

`````bash
docker image tag Dockerfile-sans-tag:latest network-utils/dockerfile-sans-tag:toolbox:1.0
`````

*Note : ERREUR : référence cible non valide.*

**Entrée 079** — **erreur relevée**

`````bash
docker image tag dockerfile-sans-tag:latest network-utils/dockerfile-sans-tag:toolbox:1.0
`````

*Note : ERREUR : référence cible non valide.*

**Entrée 080** — **erreur relevée**

`````bash
docker image tag dockerfile-sans-tag network-utils/dockerfile-sans-tag:toolbox:1.0
`````

*Note : ERREUR : référence cible non valide.*

**Entrée 081**

`````bash
cd ..
`````

**Entrée 082**

`````bash
mkdir toolbox
`````

**Entrée 083**

`````bash
cd toolbox/
`````

**Entrée 084**

`````bash
nano Dockerfile
`````

**Entrée 085**

`````bash
docker build .
`````

*Note : Build sans tag : image éventuellement « dangling » ou sans nom lisible.*

**Entrée 086**

`````bash
docker image ls
`````

**Entrée 087**

`````bash
docker image ls -a
`````

**Entrée 088**

`````bash
docker image ls --filter dangling=true
`````

**Entrée 089**

`````bash
docker image ls -a
`````

**Entrée 090**

`````bash
docker image ls --filter dangling=true
`````

**Entrée 091**

`````bash
docker image ls -a
`````

**Entrée 092**

`````bash
docker tag 25642431454c toolbox:1.0
`````

*Note : Tentative de création du tag toolbox:1.0 à partir d’un ID d’image.*

**Entrée 093** — **erreur relevée**

`````bash
docker image ls -adocker image ls
`````

*Note : ERREUR : deux commandes collées sans séparateur.*

**Entrée 094**

`````bash
docker image ls
`````

### Tags, copie du projet, Git et signature SSH — entrées 95 à 121

**Entrée 095**

`````bash
cd ~/toolbox

# Construire une deuxième référence d'image
docker build -t toolbox:2.0 .

# Ajouter le tag latest
docker image tag toolbox:2.0 toolbox:latest

# Vérifier les références
docker image ls toolbox

# Comparer les identifiants réels
docker image inspect toolbox:1.0 --format '{{.Id}}'
docker image inspect toolbox:2.0 --format '{{.Id}}'
`````

*Note : Comparaison des identifiants d’images taguées.*

**Entrée 096**

`````bash
cd ~/Docker-Network-Toolkit

# Vérifier que tu es dans le bon dépôt
git status

# Copier ton Dockerfile de diagnostic
cp ~/network-utils/Dockerfile containers/toolbox/Dockerfile

# Vérifier son contenu
cat containers/toolbox/Dockerfile

# Reconstruire depuis le dépôt
docker build -t docker-network-toolkit/toolbox:1.0 \
  ./containers/toolbox
`````

*Note : Copie d’un Dockerfile dans l’ancien dépôt local.*

**Entrée 097**

`````bash
cd ~/Docker-Network-Toolkit

git remote -v
git branch -avv
git status
`````

**Entrée 098**

`````bash
git pull
`````

*Note : Tentative Git pull dans l’ancien dépôt local sans remote correctement configuré.*

**Entrée 099** — **erreur relevée**

`````bash
git pull main
`````

*Note : ERREUR : git pull main confond remote et branche.*

**Entrée 100**

`````bash
# Tester la version 1.0
docker run --rm toolbox:1.0 curl --version

# Tester la version 2.0
docker run --rm toolbox:2.0 curl --version

# Tester le tag latest
docker run --rm toolbox:latest curl --version
`````

**Entrée 101**

`````bash
docker run -dit \
  --name toolbox-session \
  network-utils:latest

docker ps
docker exec toolbox-session ip a
docker inspect toolbox-session
`````

**Entrée 102**

`````bash
cd ~

git clone https://github.com/RufusTheDwarf/Docker-Network-Toolkit.git Docker-Network-Toolkit-github

cd ~/Docker-Network-Toolkit-github

git remote -v
git status
git log -1 --oneline
`````

*Note : Clone du dépôt officiel GitHub dans un dossier séparé.*

**Entrée 103**

`````bash
git --version
ls -la ~/.ssh
`````

**Entrée 104**

`````bash
ssh-keygen -t ed25519 \
  -C "Docker Network Toolkit - Git Signing" \
  -f ~/.ssh/id_ed25519_signing
`````

*Note : Création de la paire de clés SSH de signature.*

**Entrée 105**

`````bash
cat ~/.ssh/id_ed25519_signing.pub
`````

*Note : Affichage de la clé publique (pas de clé privée dans l’historique).*

**Entrée 106**

`````bash
git config --global gpg.format ssh
git config --global user.signingkey ~/.ssh/id_ed25519_signing.pub
git config --global commit.gpgsign true
`````

*Note : Configuration de la signature SSH des commits.*

**Entrée 107**

`````bash
git config --global --get gpg.format
git config --global --get user.signingkey
git config --global --get commit.gpgsign
`````

**Entrée 108**

`````bash
git config --global user.name
git config --global user.email
`````

**Entrée 109**

`````bash
git config --global user.name "RufusTheDwarf"
`````

**Entrée 110**

`````bash
git config --global user.email "[EMAIL_MASQUÉ]"
`````

*Note : Adresse e-mail volontairement masquée dans ce document.*

**Entrée 111**

`````bash
git config --global --get user.name
git config --global --get user.email
git config --global --get gpg.format
git config --global --get user.signingkey
git config --global --get commit.gpgsign
`````

**Entrée 112**

`````bash
cd ~/Docker-Network-Toolkit-github

rsync -avhn --ignore-existing \
  --exclude='.git/' \
  --exclude='.env' \
  --exclude='.env.*' \
  --exclude='*.pem' \
  --exclude='*.key' \
  ~/Docker-Network-Toolkit/ \
  ~/Docker-Network-Toolkit-github/
`````

*Note : Simulation rsync (-n), sans copier les fichiers.*

**Entrée 113**

`````bash
rsync -avh --ignore-existing \
  --exclude='.git/' \
  --exclude='.env' \
  --exclude='.env.*' \
  --exclude='*.pem' \
  --exclude='*.key' \
  ~/Docker-Network-Toolkit/ \
  ~/Docker-Network-Toolkit-github/
`````

*Note : Copie réelle rsync, en conservant les fichiers déjà présents.*

**Entrée 114**

`````bash
cp ~/Docker-Network-Toolkit/containers/toolbox/Dockerfile \
   ~/Docker-Network-Toolkit-github/containers/toolbox/Dockerfile
`````

**Entrée 115**

`````bash
cd ~/Docker-Network-Toolkit-github

git status --short
git diff
`````

**Entrée 116**

`````bash
sed -i 's/^FROM ubuntu:latest$/FROM ubuntu:24.04/' \
  containers/toolbox/Dockerfile
`````

*Note : Remplacement de l’image ubuntu:latest par ubuntu:24.04.*

**Entrée 117**

`````bash
docker compose config -q
bash -n scripts/test-stack.sh
`````

**Entrée 118**

`````bash
git add -A

git diff --cached --check
git diff --cached --stat
git diff --cached
`````

*Note : Vérification des modifications avant commit.*

**Entrée 119**

`````bash
git commit -S -m "feat: integrate Docker network laboratory"
`````

*Note : Commit d’intégration signé.*

**Entrée 120**

`````bash
git cat-file -p HEAD | grep -A 2 '^gpgsig'
`````

**Entrée 121**

`````bash
cat compose.yaml
cat scripts/test-stack.sh
`````

### Correction et reconstruction de la Toolbox — entrées 122 à 135

**Entrée 122** — **erreur relevée**

`````bash
FROM ubuntu:24.04

RUN apt-get update \
    && apt-get install -y --no-install-recommends \
       nmap \
       iproute2 \
       iputils-ping \
       curl \
       iperf3 \
    && rm -rf /var/lib/apt/lists/*

CMD ["bash"]
`````

*Note : ERREUR : instructions Dockerfile saisies dans le terminal plutôt que dans le fichier.*

**Entrée 123**

`````bash
docker compose ps -a

docker ps --format 'table {{.Names}}\t{{.Ports}}'

for c in dnt-web dnt-iperf3; do
  docker inspect --format \
    '{{.Name}} | project={{index .Config.Labels "com.docker.compose.project"}} | service={{index .Config.Labels "com.docker.compose.service"}}' \
    "$c"
done
`````

**Entrée 124**

`````bash
nano containers/toolbox/Dockerfile
`````

**Entrée 125**

`````bash
docker compose build toolbox
`````

*Note : Reconstruction initiale de la Toolbox.*

**Entrée 126**

`````bash
docker run --rm docker-network-toolkit/toolbox:1.0 \
  bash -lc 'for cmd in getent ping curl nmap iperf3; do command -v "$cmd" || exit 1; done'
`````

*Note : Vérification des commandes installées (premier essai).*

**Entrée 127**

`````bash
cat -n containers/toolbox/Dockerfile
`````

*Note : Inspection numérotée du Dockerfile : détection de contenu erroné.*

**Entrée 128**

`````bash
cat > containers/toolbox/Dockerfile <<'EOF'
FROM ubuntu:24.04

RUN apt-get update \
    && DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
       nmap \
       iproute2 \
       iputils-ping \
       curl \
       iperf3 \
    && rm -rf /var/lib/apt/lists/*

CMD ["bash"]
EOF
`````

*Note : Correction du Dockerfile complet par écrasement contrôlé du fichier.*

**Entrée 129**

`````bash
docker compose build --no-cache toolbox
`````

*Note : Reconstruction de la Toolbox sans cache.*

**Entrée 130**

`````bash
docker run --rm docker-network-toolkit/toolbox:1.0 \
  bash -lc '
for cmd in getent ping curl nmap iperf3; do
  command -v "$cmd" || exit 1
done
'
`````

*Note : Vérification des exécutables getent, ping, curl, nmap et iperf3.*

**Entrée 131**

`````bash
docker compose ps -a

docker ps --format \
  'table {{.Names}}\t{{.Status}}\t{{.Ports}}'

for c in dnt-web dnt-iperf3; do
  docker inspect --format \
    '{{.Name}} | project={{index .Config.Labels "com.docker.compose.project"}} | service={{index .Config.Labels "com.docker.compose.service"}}' \
    "$c"
done
`````

**Entrée 132**

`````bash
cat containers/iperf3/Dockerfile
`````

**Entrée 133**

`````bash
cd ~/Docker-Network-Toolkit-github

docker compose up -d --no-deps --force-recreate toolbox
`````

*Note : Recréation ciblée de la Toolbox sans toucher aux autres services.*

**Entrée 134**

`````bash
docker compose ps -a
`````

**Entrée 135**

`````bash
bash scripts/test-stack.sh
`````

*Note : Exécution de la suite de tests, résultats réussis observés dans la conversation.*

### Commits, authentification SSH, push et vérifications finales — entrées 136 à 147

**Entrée 136**

`````bash
cd ~/Docker-Network-Toolkit-github

git status

git add containers/toolbox/Dockerfile

git diff --cached --check

git commit -S -m "fix: complete toolbox network dependencies"

git push origin main
`````

*Note : Commit de correction puis tentative de push HTTPS avec demande d’identifiants.*

**Entrée 137**

`````bash
cat ~/.ssh/id_ed25519_signing.pub
`````

**Entrée 138**

`````bash
ssh -i ~/.ssh/id_ed25519_signing \
  -o IdentitiesOnly=yes \
  -T git@github.com
`````

*Note : Test SSH sur GitHub avec clé explicite.*

**Entrée 139**

`````bash
cd ~/Docker-Network-Toolkit-github

git remote set-url origin \
  git@github.com:RufusTheDwarf/Docker-Network-Toolkit.git

git config --local core.sshCommand \
  "ssh -i $HOME/.ssh/id_ed25519_signing -o IdentitiesOnly=yes"

git remote -v
`````

*Note : Bascule du remote Git en SSH et configuration du dépôt local.*

**Entrée 140**

`````bash
git push origin main
`````

*Note : Push GitHub réussi, confirmé dans la conversation.*

**Entrée 141**

`````bash
git status -sb
git log -2 --oneline
`````

**Entrée 142**

`````bash
git --no-pager log -2 --oneline
`````

*Note : Consultation des deux derniers commits sans pager.*

**Entrée 143**

`````bash
git status -sb
git log -2 --oneline
`````

**Entrée 144**

`````bash
git --no-pager log -2 --oneline
`````

**Entrée 145**

`````bash
cd ~/Docker-Network-Toolkit-github
git pull --ff-only
`````

*Note : Récupération des modifications distantes créées depuis GitHub.*

**Entrée 146**

`````bash
docker compose ps
docker port dnt-web
sudo ufw status verbose
`````

*Note : Vérification des services, port publié et pare-feu UFW.*

**Entrée 147**

`````bash
cd ~/Docker-Network-Toolkit-github

git pull --ff-only
git status -sb
git log -3 --oneline
`````

*Note : Synchronisation et contrôle de l’état local.*

## Remarques pour le rapport

- Cet historique permet d’identifier l’ordre de saisie, **pas** les heures, durées ni les codes de retour des commandes.
- Plusieurs entrées contiennent des commandes collées avec des sauts de ligne : leur ordre interne est conservé.
- Les essais incorrects font partie du travail de dépannage. Ils sont conservés et signalés pour expliquer la progression.
- Les commandes `FROM`, `RUN` et `CMD` doivent figurer dans un `Dockerfile`, pas être exécutées directement dans Zsh.
- L’accès au groupe `docker` peut donner des privilèges équivalents à root : ne le configurer que sur une machine de confiance.
- Les options `rsync --ignore-existing` et `rsync -n` ont permis d’éviter l’écrasement des fichiers existants et de prévisualiser les copies.
- Les tests Docker ont été validés dans la conversation ; le résultat n’est pas inféré uniquement du listing Zsh.
- Le transfert final a fonctionné après passage du remote GitHub en SSH.
