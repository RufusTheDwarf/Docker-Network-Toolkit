# Commandes utiles — Docker Network Toolkit

> Sélection des principales commandes effectivement présentes dans le journal Zsh. Ce guide n’est **pas** une liste de toutes les commandes ; le fichier `Historique_Docker_Network_Toolkit_Complet.md` est exhaustif.

## Installation et contrôle Docker

### Entrée 4

`````bash
set -e

. /etc/os-release

case "$ID" in
  debian)
    DOCKER_OS="debian"
    DOCKER_CODENAME="$VERSION_CODENAME"
    ;;
  ubuntu)
    DOCKER_OS="ubuntu"
    DOCKER_CODENAME="${UBUNTU_CODENAME:-$VERSION_CODENAME}"
    ;;
  *)
    echo "Distribution non prise en charge : $ID"
    return 1 2>/dev/null || exit 1
    ;;
esac

sudo apt update
sudo apt install -y ca-certificates curl

sudo install -m 0755 -d /etc/apt/keyrings

sudo curl -fsSL "https://download.docker.com/linux/$DOCKER_OS/gpg" \
  -o /etc/apt/keyrings/docker.asc

sudo chmod a+r /etc/apt/keyrings/docker.asc

sudo tee /etc/apt/sources.list.d/docker.sources > /dev/null <<EOF
Types: deb
URIs: https://download.docker.com/linux/$DOCKER_OS
Suites: $DOCKER_CODENAME
Components: stable
Architectures: $(dpkg --print-architecture)
Signed-By: /etc/apt/keyrings/docker.asc
EOF

sudo apt update

sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

sudo systemctl enable --now docker

sudo docker run hello-world

docker compose version
`````

*Script de configuration du dépôt officiel Docker et installation du moteur, des plugins Buildx/Compose et du service.*

### Entrée 5

`````bash
sudo usermod -aG docker "$USER"
newgrp docker
`````

*Ajout de l’utilisateur au groupe docker : équivaut à un accès privilégié au démon Docker.*

### Entrée 7

`````bash
docker version
docker compose version
docker run hello-world
`````

### Entrée 13

`````bash
id -nG
docker version
docker run hello-world
docker compose version
`````

## Création du laboratoire

### Entrée 14

`````bash
mkdir -p ~/Docker-Network-Toolkit/{containers/toolbox,containers/iperf3,web,scripts,docs/architecture,docs/tests,.github/workflows}

cd ~/Docker-Network-Toolkit

pwd
`````

*Création de l’arborescence initiale du laboratoire.*

### Entrée 15

`````bash
cat > containers/toolbox/Dockerfile <<'EOF'
FROM debian:trixie-slim

ENV DEBIAN_FRONTEND=noninteractive

RUN apt-get update \
    && apt-get install -y --no-install-recommends \
        bash \
        ca-certificates \
        curl \
        dnsutils \
        fzf \
        iperf3 \
        iproute2 \
        iputils-ping \
        mtr-tiny \
        netcat-openbsd \
        nmap \
        procps \
        tcpdump \
        traceroute \
        wget \
        less \
        vim-tiny \
    && rm -rf /var/lib/apt/lists/*

WORKDIR /workspace

CMD ["sleep", "infinity"]
EOF
`````

*Version initiale du Dockerfile toolbox basée sur Debian.*

### Entrée 16

`````bash
cat > containers/iperf3/Dockerfile <<'EOF'
FROM debian:trixie-slim

ENV DEBIAN_FRONTEND=noninteractive

RUN apt-get update \
    && apt-get install -y --no-install-recommends iperf3 passwd \
    && rm -rf /var/lib/apt/lists/* \
    && useradd --system --uid 10001 --no-create-home iperf

USER 10001:10001

EXPOSE 5201

CMD ["iperf3", "--server"]
EOF
`````

*Dockerfile iperf3 avec utilisateur non privilégié 10001.*

### Entrée 17

`````bash
cat > web/index.html <<'EOF'
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Docker Network Toolkit</title>
</head>
<body>
    <h1>Docker Network Toolkit</h1>
    <p>Le serveur web fonctionne correctement.</p>
    <p>Service : web</p>
    <p>Infrastructure : Docker Compose</p>
</body>
</html>
EOF
`````

### Entrée 18

`````bash
cat > compose.yaml <<'EOF'
name: docker-network-toolkit

services:
  toolbox:
    build:
      context: ./containers/toolbox
    image: docker-network-toolkit/toolbox:1.0
    container_name: dnt-toolbox
    command: ["sleep", "infinity"]
    working_dir: /workspace
    cap_add:
      - NET_RAW
    networks:
      - toolkit

  web:
    image: nginx:stable-alpine
    container_name: dnt-web
    ports:
      - "8080:80"
    volumes:
      - ./web:/usr/share/nginx/html:ro
    restart: unless-stopped
    networks:
      - toolkit

  iperf3-server:
    build:
      context: ./containers/iperf3
    image: docker-network-toolkit/iperf3-server:1.0
    container_name: dnt-iperf3
    expose:
      - "5201"
    restart: unless-stopped
    networks:
      - toolkit

networks:
  toolkit:
    name: dnt-network
    driver: bridge
EOF
`````

*Configuration initiale des trois services Compose et du réseau dnt-network.*

### Entrée 19

`````bash
cat > scripts/test-stack.sh <<'EOF'
#!/usr/bin/env bash

set -euo pipefail

docker compose exec -T toolbox bash -lc '
set -euo pipefail

echo "===== DNS ====="
getent hosts web
getent hosts iperf3-server

echo
echo "===== PING ====="
ping -c 3 web

echo
echo "===== HTTP ====="
curl -fsS http://web/

echo
echo "===== NMAP ====="
nmap -sT -p 80 web

echo
echo "===== IPERF3 ====="
iperf3 -c iperf3-server -t 5

echo
echo "Tous les tests ont réussi."
'
EOF

chmod +x scripts/test-stack.sh
`````

*Création du script de test automatique du réseau.*

### Entrée 20

`````bash
cat > .gitignore <<'EOF'
.env
.env.*
!.env.example

*.log
*.pcap
*.pcapng

backup/
backups/
tmp/

.DS_Store
EOF
`````

### Entrée 21

`````bash
docker compose config -q
`````

*Validation de syntaxe de Compose.*

### Entrée 22

`````bash
docker compose up -d --build
`````

*Construction et démarrage de la stack.*

### Entrée 23

`````bash
docker compose ps
`````

### Entrée 24

`````bash
curl http://localhost:8080
`````

### Entrée 25

`````bash
./scripts/test-stack.sh
`````

## Diagnostics et architecture réseau

### Entrée 26

`````bash
echo "========== MACHINE VIRTUELLE =========="
hostname
ip -br addr
ip route

echo
echo "========== RESEAU DOCKER =========="
docker network inspect dnt-network

echo
echo "========== ADRESSES DES CONTENEURS =========="
for container in dnt-toolbox dnt-web dnt-iperf3; do
    echo "===== $container ====="
    docker inspect -f '{{range .NetworkSettings.Networks}}{{.IPAddress}}/{{.IPPrefixLen}} | Gateway: {{.Gateway}}{{end}}' "$container"
done

echo
echo "========== PORTS EXPOSES =========="
docker compose port web 80
`````

*Relevé de la VM, du réseau Docker et des adresses des conteneurs.*

### Entrée 28

`````bash
systemd-detect-virt
`````

### Entrée 29

`````bash
curl -I http://192.168.196.131:8080
`````

### Entrée 30

`````bash
sudo ss -lntp | grep -E ':8080|:5201'
`````

### Entrée 33

`````bash
find . -maxdepth 3 -type f | sort
`````

*Ajout de la section test d’accès HTTP depuis Windows.*

## Images, tags et conteneurs

### Entrée 51

`````bash
nano Dockerfile
`````

### Entrée 53

`````bash
docker build -t network-utils:latest .
`````

*Construction de l’image network-utils.*

### Entrée 54

`````bash
docker images
`````

### Entrée 55

`````bash
docker run -dit --name network-utils network-utils:latest
`````

*Démarrage d’un conteneur de diagnostic.*

### Entrée 57

`````bash
docker exec network-utils nmap -h
`````

### Entrée 58

`````bash
docker exec network-utils ip a
`````

### Entrée 59

`````bash
docker exec network-utils ping -c 1 8.8.8.8
`````

### Entrée 73

`````bash
ls
`````

### Entrée 74

`````bash
docker image ls
`````

### Entrée 85

`````bash
docker build .
`````

*Build sans tag : image éventuellement « dangling » ou sans nom lisible.*

### Entrée 86

`````bash
docker image ls
`````

### Entrée 88

`````bash
docker image ls --filter dangling=true
`````

### Entrée 92

`````bash
docker tag 25642431454c toolbox:1.0
`````

*Tentative de création du tag toolbox:1.0 à partir d’un ID d’image.*

### Entrée 95

`````bash
cd ~/toolbox

# Construire une deuxième référence d'image
docker build -t toolbox:2.0 .

# Ajouter le tag latest
docker image tag toolbox:2.0 toolbox:latest

# Vérifier les références
docker image ls toolbox

# Comparer les identifiants réels
docker image inspect toolbox:1.0 --format '{{.Id}}'
docker image inspect toolbox:2.0 --format '{{.Id}}'
`````

*Comparaison des identifiants d’images taguées.*

### Entrée 100

`````bash
# Tester la version 1.0
docker run --rm toolbox:1.0 curl --version

# Tester la version 2.0
docker run --rm toolbox:2.0 curl --version

# Tester le tag latest
docker run --rm toolbox:latest curl --version
`````

### Entrée 101

`````bash
docker run -dit \
  --name toolbox-session \
  network-utils:latest

docker ps
docker exec toolbox-session ip a
docker inspect toolbox-session
`````

## Migration vers le dépôt GitHub et signature

### Entrée 102

`````bash
cd ~

git clone https://github.com/RufusTheDwarf/Docker-Network-Toolkit.git Docker-Network-Toolkit-github

cd ~/Docker-Network-Toolkit-github

git remote -v
git status
git log -1 --oneline
`````

*Clone du dépôt officiel GitHub dans un dossier séparé.*

### Entrée 104

`````bash
ssh-keygen -t ed25519 \
  -C "Docker Network Toolkit - Git Signing" \
  -f ~/.ssh/id_ed25519_signing
`````

*Création de la paire de clés SSH de signature.*

### Entrée 106

`````bash
git config --global gpg.format ssh
git config --global user.signingkey ~/.ssh/id_ed25519_signing.pub
git config --global commit.gpgsign true
`````

*Configuration de la signature SSH des commits.*

### Entrée 112

`````bash
cd ~/Docker-Network-Toolkit-github

rsync -avhn --ignore-existing \
  --exclude='.git/' \
  --exclude='.env' \
  --exclude='.env.*' \
  --exclude='*.pem' \
  --exclude='*.key' \
  ~/Docker-Network-Toolkit/ \
  ~/Docker-Network-Toolkit-github/
`````

*Simulation rsync (-n), sans copier les fichiers.*

### Entrée 113

`````bash
rsync -avh --ignore-existing \
  --exclude='.git/' \
  --exclude='.env' \
  --exclude='.env.*' \
  --exclude='*.pem' \
  --exclude='*.key' \
  ~/Docker-Network-Toolkit/ \
  ~/Docker-Network-Toolkit-github/
`````

*Copie réelle rsync, en conservant les fichiers déjà présents.*

### Entrée 114

`````bash
cp ~/Docker-Network-Toolkit/containers/toolbox/Dockerfile \
   ~/Docker-Network-Toolkit-github/containers/toolbox/Dockerfile
`````

### Entrée 116

`````bash
sed -i 's/^FROM ubuntu:latest$/FROM ubuntu:24.04/' \
  containers/toolbox/Dockerfile
`````

*Remplacement de l’image ubuntu:latest par ubuntu:24.04.*

### Entrée 117

`````bash
docker compose config -q
bash -n scripts/test-stack.sh
`````

### Entrée 118

`````bash
git add -A

git diff --cached --check
git diff --cached --stat
git diff --cached
`````

*Vérification des modifications avant commit.*

### Entrée 119

`````bash
git commit -S -m "feat: integrate Docker network laboratory"
`````

*Commit d’intégration signé.*

### Entrée 120

`````bash
git cat-file -p HEAD | grep -A 2 '^gpgsig'
`````

## Correction et tests finaux

### Entrée 124

`````bash
nano containers/toolbox/Dockerfile
`````

### Entrée 125

`````bash
docker compose build toolbox
`````

*Reconstruction initiale de la Toolbox.*

### Entrée 127

`````bash
cat -n containers/toolbox/Dockerfile
`````

*Inspection numérotée du Dockerfile : détection de contenu erroné.*

### Entrée 128

`````bash
cat > containers/toolbox/Dockerfile <<'EOF'
FROM ubuntu:24.04

RUN apt-get update \
    && DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
       nmap \
       iproute2 \
       iputils-ping \
       curl \
       iperf3 \
    && rm -rf /var/lib/apt/lists/*

CMD ["bash"]
EOF
`````

*Correction du Dockerfile complet par écrasement contrôlé du fichier.*

### Entrée 129

`````bash
docker compose build --no-cache toolbox
`````

*Reconstruction de la Toolbox sans cache.*

### Entrée 130

`````bash
docker run --rm docker-network-toolkit/toolbox:1.0 \
  bash -lc '
for cmd in getent ping curl nmap iperf3; do
  command -v "$cmd" || exit 1
done
'
`````

*Vérification des exécutables getent, ping, curl, nmap et iperf3.*

### Entrée 133

`````bash
cd ~/Docker-Network-Toolkit-github

docker compose up -d --no-deps --force-recreate toolbox
`````

*Recréation ciblée de la Toolbox sans toucher aux autres services.*

### Entrée 134

`````bash
docker compose ps -a
`````

### Entrée 135

`````bash
bash scripts/test-stack.sh
`````

*Exécution de la suite de tests, résultats réussis observés dans la conversation.*

## Publication et synchronisation Git

### Entrée 136

`````bash
cd ~/Docker-Network-Toolkit-github

git status

git add containers/toolbox/Dockerfile

git diff --cached --check

git commit -S -m "fix: complete toolbox network dependencies"

git push origin main
`````

*Commit de correction puis tentative de push HTTPS avec demande d’identifiants.*

### Entrée 138

`````bash
ssh -i ~/.ssh/id_ed25519_signing \
  -o IdentitiesOnly=yes \
  -T git@github.com
`````

*Test SSH sur GitHub avec clé explicite.*

### Entrée 139

`````bash
cd ~/Docker-Network-Toolkit-github

git remote set-url origin \
  git@github.com:RufusTheDwarf/Docker-Network-Toolkit.git

git config --local core.sshCommand \
  "ssh -i $HOME/.ssh/id_ed25519_signing -o IdentitiesOnly=yes"

git remote -v
`````

*Bascule du remote Git en SSH et configuration du dépôt local.*

### Entrée 140

`````bash
git push origin main
`````

*Push GitHub réussi, confirmé dans la conversation.*

### Entrée 141

`````bash
git status -sb
git log -2 --oneline
`````

### Entrée 142

`````bash
git --no-pager log -2 --oneline
`````

*Consultation des deux derniers commits sans pager.*

### Entrée 145

`````bash
cd ~/Docker-Network-Toolkit-github
git pull --ff-only
`````

*Récupération des modifications distantes créées depuis GitHub.*

### Entrée 146

`````bash
docker compose ps
docker port dnt-web
sudo ufw status verbose
`````

*Vérification des services, port publié et pare-feu UFW.*

### Entrée 147

`````bash
cd ~/Docker-Network-Toolkit-github

git pull --ff-only
git status -sb
git log -3 --oneline
`````

*Synchronisation et contrôle de l’état local.*

## Commandes incorrectes observées

Les entrées 36, 42, 65–69, 76–80, 93, 99 et 122 sont des tentatives erronées ou une syntaxe incorrecte. Elles sont conservées dans l’historique complet, mais ne doivent pas être utilisées comme exemples à reproduire.
